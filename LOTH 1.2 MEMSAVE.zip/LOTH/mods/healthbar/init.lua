playernutritions = {}
playerhealthhuds = {}
local armor_register = {}
local mining_players_with_black_skies = {}
local normal_armor_of_player = {}
local last_armor_values_of_player = {}
local healthbar_chat_command_removal = true
health_data_file_name = minetest.get_worldpath() .. "/players/"
maxnutritions= {999,999,999,999,999}
function get_player_healthvals(name)
	local input = io.open(minetest.get_worldpath() .. "/players/" .. name .. "healthvals.txt", "r")
	if input then
		local data = input:read("*all")
		if data then
			db({data})
			local table = {}
			local index = 1
			for i in string.gmatch(data, '([^#]+)') do
				db({i})
				table[index] = tonumber(i)
				index = index+1
			end
			if table[1] then
				return table
			end
		end
        	io.close(input)
	else
	end
end
local function clean_spawn_job_list(tstamp)
local updated = {}
local tstamp = tstamp or math.floor(minetest.get_gametime()/10)
for i,_ in pairs(default_mob_spawn_jobs) do
if not (i < tstamp) then
updated[i] = default_mob_spawn_jobs[i]
else
end
end
default_mob_spawn_jobs = updated
end
if healthbar_chat_command_removal then
minetest.after(0,function()
minetest.chatcommands["grant"] = nil
minetest.chatcommands["teleport"] = nil
end)
end
--function healthbar_play_attack_sound(attacked)
--[[minetest.sound_play("tnt_explode.ogg", {
	pos = attacked:getpos(),
	max_hear_distance = 100,
	gain = 10.0,]]
--})
--end
local function maintain_spawn_job_list()
local timestamp = math.floor(minetest.get_gametime()/10)
for _,e in pairs(default_mob_spawn_jobs[timestamp] or {}) do
minetest.add_entity(e.pos,e.entity)
end
if timestamp%6 == 0 then
clean_spawn_job_list(timestamp)
end
end
function update_health_data_file(name,healthvals)
	local input = io.open(health_data_file_name .. name .. "healthvals.txt", "w")
	if input then
 	input:write(table.concat(healthvals, "#"))
	io.close(input)
	end
end
function add_health_table_to_player_health_data(player,table)
	local name = player:get_player_name()
	if playernutritions[name] then
		local newnutritions = {}
		for ind,ele in pairs(playernutritions[name]) do
			newnutritions[ind] = math.max(0,ele + table[ind])
		end
		playernutritions[name] = newnutritions
		update_health_data_file(name,newnutritions)
	end
end
function poisoning_standard(player,table)
	local name = player:get_player_name()
	if playernutritions[name] then
		local newnutritions = {}
		for ind,ele in pairs(playernutritions[name]) do
			newnutritions[ind] = math.max(0,ele - table)
		end
		playernutritions[name] = newnutritions
		update_health_data_file(name,newnutritions)
		return true
	end
end
local function register_creator_cmd()
minetest.register_chatcommand("creator", {
	params = "",
	description = "find out about creator",
	func = function(name, param)
		minetest.chat_send_all("This Subgame was created by Kai Gerd Müller using the default Minetest Subgame minetest_game as base")
	end,
})
end
register_creator_cmd()
minetest.after(1,register_creator_cmd)
minetest.after(3,register_creator_cmd)
minetest.after(10,register_creator_cmd)
function new_poison_storage(max_ammount,charge_ammount,starting_ammount)
	return {
		ammount = starting_ammount or max_ammount,
		charge = function(self)
			self.ammount = math.min(self.ammount + charge_ammount,max_ammount)
			return self
		end,
		poison = function(self,player)
			if not poisoning_standard(player,self.ammount) then
				player:set_hp(player:get_hp()-self.ammount)
			end
			self.ammount = 0
			return self
		end
		}
end
function register_player_armor(metal,table,crafting_metal)
n = 0
for i,v in pairs({boots = 1.5,chestplate = 2.5,trousers = 1.5,helmet = 2,shield = 2.5}) do
n = n+1

minetest.register_tool("healthbar:armor_part_" .. metal .. i, {
	description = metal .. i,
	inventory_image = i .. "_blackwhite.png^default_" .. metal ..
			"_metal_overlay.png^" .. i .. "_alphamask.png^[makealpha:255,0,255"
})
local texture = false
local recipe = false
if i == "shield" then
	texture = "3d_shield_" .. metal .. ".png"
	recipe = {
		{crafting_metal, crafting_metal, crafting_metal},
		{crafting_metal, crafting_metal, crafting_metal},
		{'', crafting_metal, ''},
	}
elseif i == "boots" then
	recipe = {
		{crafting_metal, '', crafting_metal},
		{crafting_metal, '', crafting_metal},
	}
elseif i == "trousers" then
	recipe = {
		{crafting_metal, crafting_metal, crafting_metal},
		{crafting_metal, '', crafting_metal},
		{crafting_metal, '', crafting_metal},
	}
elseif i == "helmet" then
	recipe = {
		{crafting_metal, crafting_metal, crafting_metal},
		{crafting_metal, '', crafting_metal},
	}
elseif i == "chestplate"then
	recipe = {
		{crafting_metal, '', crafting_metal},
		{crafting_metal, crafting_metal,crafting_metal},
		{crafting_metal, crafting_metal,crafting_metal},
	}
end
minetest.register_craft({
	output = "healthbar:armor_part_" .. metal .. i,
	recipe = recipe
})
armor_register["healthbar:armor_part_" .. metal .. i] = {shield = (i == "shield"),protected = n,max_protection =1/(v*table.max_protection),max_level = v*(table.max_level or 1),durability = table.durability,textures = texture or "^3d_" .. i .. "_" .. metal .. ".png"}--^3d_" .. i .. "_alphamask.png^[makealpha:255,0,255)"}
--[[(default_" .. metal ..
			"_metal_3d_overlay.png^]]
end
end
register_player_armor("steel",{max_protection = 1,max_level = 0,durability = 0.05},"default:steel_ingot")
register_player_armor("mithril",{max_protection = 1.5,max_level = 0,durability = 1},"default:mithril_ingot")
register_player_armor("bronze",{max_protection = 1.1,max_level = 0,durability = 0.1},"default:bronze_ingot")
register_player_armor("galvorn",{max_protection = 1.4,max_level = 0,durability = 0.8},"default:galvorn_ingot")
function register_food(name,imagename,vitality,second_ffoood,flag_png)
local ii = ""
if flag_png then
ii = imagename
else
ii = imagename .. ".png"
end
minetest.register_craftitem(name, {
	description = (name:split(":")[2]),
	inventory_image = ii,
	on_use = function(itemstack, dropper)
		name = dropper:get_player_name()
		local vitality = vitality
		if second_ffoood and math.random(1,second_ffoood.chanche)then
			vitality = second_ffoood.nutrition
		end
		local table = playernutritions[name]
		for ind,ele in pairs(table) do
			if vitality[ind] then
				table[ind] = math.max(ele + vitality[ind],0)
			end
		end
		update_health_data_file(name,table)
		itemstack:take_item()
		return itemstack
	end,
})
end
minetest.register_on_joinplayer(function(player)
local name = player:get_player_name()
local table = get_player_healthvals(name) or "ERRNO"
if table == "ERRNO" then
	table = maxnutritions
	update_health_data_file(name,table)
end
playernutritions[name] = table
playerhealthhuds[name] = player:hud_add({
    hud_elem_type = "statbar",
    position = {x=0,y=1},
    size = "",
    text = "health.png",
    number = math.floor(2*math.min(table[1],table[2],table[3],table[4],table[5])/111),
    alignment = {x=0,y=1},
    offset = {x=0, y=-32},
})
end)
local timer = 0
local timer2 = 0
function db(message,category)
	if category == "Debug"then--"VeryImportantMessage" then
	if type(message) ~= string then
		message = table.concat(message,"+")--tostring(message)
	end
	--minetest.chat_send_all(message)
	end
end
local function add_wear_to_armor(player,d)
		db({"ADD_WEAR..."})
	local inv = player:get_inventory():get_list("main")
	for i = 33,38 do
		if inv[i] then
			local data = armor_register[inv[i]:get_name()]
			if data then
				db({"wear_added"})
				inv[i]:add_wear(math.floor((d/data.durability)+0.5))
			end
		else
			db({"CREATIVEINV?????????????!!!!!!!!!!!!!!!!!!!!!"},"VeryImportantMessage")
		end
	end
	player:get_inventory():set_list("main",inv)
end
minetest.register_on_punchplayer(function(player, hitter)
	pcall(function()
--	healthbar_play_attack_sound(player)
	if hitter then
		local luaent = hitter:get_luaentity()
		if luaent and luaent.damage then
			add_wear_to_armor(player,luaent.damage)
		elseif hitter:is_player() then
			local def = hitter:get_wielded_item():get_definition()
			if def then
				local groups = def.damage_groups
				if groups then
					local fleshy = groups.fleshy or true
					if fleshy == true then
						fleshy = 1
						for _,i in pairs(groups) do
							fleshy = math.max(fleshy,i)
						end
					end
					add_wear_to_armor(player,fleshy)
				else
					add_wear_to_armor(player,1)	
				end
			else
				add_wear_to_armor(player,1)
			end
		else
			add_wear_to_armor(player,1)
		end
	else
		add_wear_to_armor(player,1)
	end
	end)
end)
--add_wear_to_armor(player,)
local orc_detecting_swords = {["default:epic_stich"] =ItemStack("default:epic_stich_alert"),["default:epic_orccrist"] =ItemStack("default:epic_orccrist_alert"),["default:epic_stich_sibling"] =ItemStack("default:epic_stich_sibling_alert"),["default:epic_glamdring"] =ItemStack("default:epic_glamdring_alert"),["default:epic_orccrist_glamdring_sibling"] =ItemStack("default:epic_orccrist_glamdring_sibling_alert")}
local orc_detected_swords = {["default:epic_stich_alert"] =ItemStack("default:epic_stich"),["default:epic_orccrist_alert"] =ItemStack("default:epic_orccrist"),["default:epic_stich_sibling_alert"] =ItemStack("default:epic_stich_sibling"),["default:epic_glamdring_alert"] =ItemStack("default:epic_glamdring"),["default:epic_orccrist_glamdring_sibling_alert"] =ItemStack("default:epic_orccrist_glamdring_sibling")}
local function orcs_near(pos,raaa)
	local r = false
	for _,e in pairs(minetest.get_objects_inside_radius(pos,raaa))do
	local luaent = e:get_luaentity()
	if luaent then
	r = r or luaent.orc or luaent.balrog
	end
	end
	return r
end
local function get_wield_item_texture(p)
	local i = p:get_wielded_item()
	local newitem = orc_detecting_swords[i:get_name()] or false
	local newitem2 = orc_detected_swords[i:get_name()] or false
	if newitem and orcs_near(vector.add(p:getpos(),{x=0,y=30,z=0}),60)then
	p:set_wielded_item(newitem)
	i = newitem
	elseif newitem2 and (not orcs_near(vector.add(p:getpos(),{x=0,y=30,z=0}),60))then
	p:set_wielded_item(newitem2)
	i = newitem2
	end
	if (not i:is_empty()) and  i:is_known() then
		local d = i:get_definition()
		--db({d.tiles[1]},"VeryImportantMessage")
		if d.inventory_image or d.tiles then
			--db({"Tiles_fOUND"},"VeryImportantMessage")
			db({tostring(d.inventory_image == "")},"VeryImportantMessage")
			if d.inventory_image ~= "" then
				return d.inventory_image
			else
				return d.tiles[1]
			end	
		else
			return "doors_blank.png"
		end
	else
		return "doors_blank.png"
	end
end
local timer3 = 0
local function armorcurve(a,s)
for i = 1,(s or 1) do
	a = (1 - (1 / ((a / 100) + 1)))* 200
end
return a
end
local function levelcurve(a,s)
for i = 1,(s or 1) do
	a = (1 - (1 / (a  + 1)))* 2
end
return a
end
local timer4 = 0
--local timer5 = 0
local function read_sauron_exists()
	local input = io.open(health_data_file_name .. "tbvspofyjtut.txt", "r")
	local data = 1
	if input then
 	data = input:read("*n")
	io.close(input)
	end
	return (data == 1)
end
function healthbar_write_sauron_exists()
	local input = io.open(health_data_file_name .. "tbvspofyjtut.txt", "w")
	if input then
	if healthbar_sauron_exists then
 	input:write("1")
	else
 	input:write("0")
	end
	io.close(input)
	end
end
healthbar_sauron_exists = read_sauron_exists()
local timer5 = 0
minetest.register_globalstep(function(dtime)
	timer = timer+dtime
	timer2 = timer2+dtime
	timer3 = timer3+dtime
	timer4 = timer4+dtime
	timer5 = timer5+dtime
	if timer3 >= 60 then
	timer3 = 0
	collectgarbage("collect")
	--collectgarbage("collect")
	end
	if timer5 >= 300 then
	timer5 = 0
	for name,bx in pairs(sauron_killed_bosses) do
		if bx["dragons:bat"] and bx["trolls:uruguay"]and bx["nazgul:witchy"] and bx["nazgul:ghost"] and bx["balrog:balrog"] and bx["necromancer:witchy"] and bx["spiders:shelob"] and healthbar_sauron_exists then
			local player = minetest.get_player_by_name(name)
			if player then
				minetest.add_entity(player:getpos(),"sauron:sauron")
				healthbar_sauron_exists = false
				healthbar_write_sauron_exists()
			end
		end
	end
	--collectgarbage("collect")
	end
	if timer2 >= 3 then
	timer2 = 0
	for _,player in ipairs(minetest.get_connected_players()) do
	local name = player:get_player_name()
	local inv = player:get_inventory():get_list("main")
	local armortable = {true,true,true,true,true}
	normal_armor_of_player[player:get_player_name()] = 100
	local armormultipier = normal_armor_of_player[player:get_player_name()]
	local level = 1
	local shieldtex = false
	local d3tex = ""--{}
	for i = 33,38 do
		db({type(inv[i])})
		local index = i-32
		local i = inv[i]
		if i then
		local data = armor_register[i:get_name()]
		if data and armortable[data.protected] then
			--db(data,"VeryImportantMessage")
			if data.shield then
				shieldtex = data.textures
			else
				d3tex = d3tex .. data.textures--"^culumalda_tree_top.png"--data.textures --or ""
			end
			armortable[data.protected] = false
			local quality = (2-(i:get_wear()/65535))
			armormultipier = armormultipier * (data.max_protection/quality)
			db({tostring(data.max_protection == nil)},"VeryImportantMessage")
			level = level * (data.max_level / quality)
			db({"YEY! FOUND ARMOR"})
		end
		else
			db("CREATIVEINV!!!!!!!!!")
		end
	end
	db({"AAAAA"},"VeryImportantMessage")
	db({"^(3d_" .. "helmet" .. "_blackwhite.png^default_" .. "steel" ..
			"_metal_overlay.png" .. "^3d_" .. "helmet" .. "_alphamask.png^[makealpha:255,126,126)"},"VeryImportantMessage")
	db({"BBBB"},"VeryImportantMessage")
	local armorvals = {fleshy =armorcurve(armormultipier,8),level = 1}
	db({armorvals.fleshy},"Debug")
	db({get_default_properties_of_player(name,"textures")},"VeryImportantMessage")
	default.player_set_textures(player,{shieldtex or "doors_blank.png",get_wield_item_texture(player),(get_default_properties_of_player(name,"textures") or "") .. d3tex})
	if last_armor_values_of_player[name] ~= armorvals then
	last_armor_values_of_player[name] = armorvals
	player:set_armor_groups(armorvals)
	end
end
end
	if timer4 >= 9 then
	maintain_spawn_job_list()
	timer4 = 0
	end
	if timer >= 10 then
	timer = 0
	local sky_settings = false
	for _,player in ipairs(minetest.get_connected_players()) do
		local pos = player:getpos()
		local name = player:get_player_name()
		if pos.y > -30 and mining_players_with_black_skies[name] then
		mining_players_with_black_skies[name] = false
		db({"SKYCHANGE[NORMAL]"})
		player:set_sky(nil,"regular")
		elseif pos.y < -30 and mining_players_with_black_skies[name] ~= true then
		db({"SKYCHANGE[BLACK]"})
		mining_players_with_black_skies[name] = true
		player:set_sky("#000000", "plain")
		end
		local table = playernutritions[name] or "ERRNO"
		if table == "ERRNO" then
			db({"ERRNO"})
			table = maxnutritions
			update_health_data_file(name,table)
		end
		if playerhealthhuds[name] then
		player:hud_remove(playerhealthhuds[name])
		end
		db(table)
		local health = math.min(18,math.floor(2*math.min(table[1],table[2],table[3],table[4],table[5])/111))
		playerhealthhuds[name] = player:hud_add({
    			hud_elem_type = "statbar",
    			position = {x=0,y=1},
    			size = "",
    			text = "health.png",
    			number = health,
    			alignment = {x=0,y=1},
    			offset = {x=0, y=-32},
		})
		local neardead = false
		if health <= 0 then
			neardead = true
			player:set_hp(player:get_hp()-1)
		end
		if not neardead then
		if player:get_hp() < 18 and player:get_hp() > 0 then
		player:set_hp(player:get_hp()+1)
		for i =1,5 do
			if table[i] > 999 then
				table[i] = 999
			end
			if table[i] > 0 then
				table[i] = table[i] -6
			end
		end
		end
		for i =1,5 do
			if table[i]-20 > 0 then
				table[i] = table[i] -6
			else
				table[i] = 0
			end
		end
		end
		playernutritions[name] = table
		update_health_data_file(name,table)
end
end
end)
healthbar_armor_register = armor_register

