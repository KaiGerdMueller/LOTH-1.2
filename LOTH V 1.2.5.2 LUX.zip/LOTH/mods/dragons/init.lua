-- Minetest mod: jellyfish
-- (c) Kai Gerd Müller
-- See README.txt for licensing and other information.
--[[local function spawn_fire(self,pos,targetvektor)
			--local new_pos = vector.add(pos,vector.multiply(vector.normalize({x=targetvektor.x,y=0,z=targetvektor.z}),10))
			new_pos.y = new_pos.y + 6
			local targetvektor = vector.multiply(vector.normalize(vector.add(targetvektor,vector.subtract(pos,new_pos))),self.firespeed)
			--db({"TEST"},"Debug")
			local arrow = minetest.add_entity(pos,"lotharrows:dragonfire")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = self.damage
			--arrow:setyaw(math.atan2(targetvektor.z,targetvektor.x)+math.pi/2)
			--db({tostring(vector.length(targetvektor))},"Debug")
			--targetvektor = {x=0,y=10,z=0}
			arrow:setvelocity(targetvektor)
			--arrow:setacceleration({x=0,y=0,z=0})
end]]
local function spawn_fire(self,pos,pos2)
			local pos = vector.add(pos,vector.multiply(vector.normalize({x =pos2.x-pos.x,y=0,z=pos2.z-pos.z}),12))
			pos.y = pos.y + 6
			local targetvektor = vector.multiply(vector.normalize(vector.subtract(pos2,pos)),self.firespeed)
			--local targetvektor = vector.multiply(vector.normalize(vector.add(targetvektor,vector.subtract(pos,new_pos))),self.firespeed)
			--db({"TEST"},"Debug")
			local arrow = minetest.add_entity(pos,"lotharrows:dragonfire")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = user
			arrowent.damage = self.damage
			--arrow:setyaw(math.atan2(targetvektor.z,targetvektor.x)+math.pi/2)
			--db({tostring(vector.length(targetvektor))},"Debug")
			--targetvektor = {x=0,y=10,z=0}
			arrow:setvelocity(targetvektor)
			--arrow:setacceleration({x=0,y=0,z=0})
end
--[[local function spawn_fire(self,pos,targetvektor)
			--local new_pos = vector.add(pos,vector.multiply(vector.normalize({x=targetvektor.x,y=0,z=targetvektor.z}),10))
			--new_pos.y = new_pos.y + 6
			local targetvektor = vector.multiply(vector.normalize(targetvektor),self.firespeed)
			db({"TEST"},"Debug")
			local arrow = minetest.add_entity(pos,"lotharrows:dragonfire")
			local arrowent = arrow:get_luaentity()
			arrowent.shooter = 
			arrowent.damage = self.damage
			--arrow:setyaw(math.atan2(targetvektor.z,targetvektor.x)+math.pi/2)
			--arrow:setvelocity(targetvektor)
			--arrow:setacceleration({x=0,y=0,z=0})
end]]
local function register_spawn(name, nodes,chanche)
	default_register_sbm({
	label = "spawn",
	catch_up = false,
		nodenames = nodes,
		interval = 10,
		chance = chanche,
		action = function(pos)
			pos.y = pos.y + math.random(1,20)
			local n = minetest.get_node(pos).name
			if n == "air" or n == "ignore" then
				minetest.add_entity(pos, name)
			end
		end
	})
end
local function get_nearest_enemy(self,pos,radius,fucking_punchtest)
	local min_dist = 51
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,radius)) do
		local luaent = entity:get_luaentity()
		local name = entity:get_player_name()
		if (luaent and (not luaent.balrog)) or entity:is_player() then
		local p = entity:getpos()
		local dist = vector.distance(pos,p)
				if default_do_not_punch_this_stuff(luaent) and dist < min_dist then
			min_dist = dist
				target = entity
		end
		end
	end
--if target and ((not fucking_punchtest) or minetest.line_of_sight(target:getpos(),pos,2)) then
--return target
--else
return target
--end
end
local function animate(self, t)
	if t == 1 and self.canimation ~= 1 then
		self.object:set_animation({
			x = 0,
			y = 250},
			150, 0)
		self.canimation = 1
	elseif t == 2 and self.canimation ~= 2 then
		self.object:set_animation({x = 0,y = 250},300, 0)
		self.canimation = 2
	--walkmine
	end
end
local function register_jellyfish_advanced(name, def)
	local defbox = def.size/3
	local side2 = name .. "3.png"
	local side = name .. "2.png"
	local front = name .. "1.png"
	minetest.register_entity("dragons:" .. name,{
		initial_properties = {
			name = "dragons:" .. name,
			hp_max = def.max_hp,
			visual_size = {x = def.size*5, y = def.size*5, z = def.size*5},
			visual = "mesh",
			mesh = "uruloki2000.b3d",
			textures = {"spiderskin.png^dragon_eye_overlay.png"},
			collisionbox = {-defbox, -defbox, -defbox, defbox, defbox, defbox},
			physical = true
		},
		-- ON ACTIVATE --
		on_punch = default_add_boss_kill_flag,
		on_activate = function(self,static)
			self.firespeed = 20
			self.dragonproof = true
			self.damage= def.damage
			self.arrow_resistant = true
			self.dragon = true
			self.balrog = true
			self.object:set_properties({automatic_rotate = 0})
--			self.orc = true
			self.targetvektor = {x=0, y = 0 , z = 0 }
			self.object:setacceleration({x = 0, y = 0, z = 0})
			self.object:setvelocity({x = math.random(-1,1), y = math.random(-1,1), z = math.random(-1,1)})
			self.lifetimer = 0
			self.timer = 0
			self.regentimer = tonumber(static) or 1800
		end,
		get_staticdata = function(self)
		return tostring(self.regentimer)
		end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = function(self, dtime)
			self.regentimer = self.regentimer-dtime
			if self.regentimer < 0 then
			self.regentimer = 1800
			self.object:set_hp(def.max_hp)
			end
			local animation = 1
			local target = false
			self.timer = self.timer + dtime
			self.lifetimer = self.lifetimer + dtime
			if self.lifetimer > 6000 then
				self.object:remove()
			end
			local pos = self.object:getpos()
			if not(self.object:get_hp() > 0) then
				pos.y = pos.y + 0.5
				self.object:remove()
				obj = minetest.add_item(pos, ItemStack("default:diamondblock 10"))
				obj:setvelocity({x=math.random(-1,1), y=5, z=math.random(-1,1)})
			end
			if math.random(1,50) == 1 then
				if pos.y < 200 then
				self.targetvektor = vector.multiply(vector.normalize({x=math.random(-10,10),y=math.random(-10,10),z=math.random(-10,10)}),def.speed)
				else
				self.targetvektor = vector.multiply(vector.normalize({x=math.random(-10,10),y=math.random(-10,0),z=math.random(-10,10)}),def.speed)
				end
				--targetdistance = math.sqrt((targetvektor.x*targetvektor.x)+(targetvektor.y*targetvektor.y)+(targetvektor.z*targetvektor.z))
				--targetvektor = {x=(targetvektor.x/targetdistance)*def.speed,y=(targetvektor.y/targetdistance)*def.speed,z=(targetvektor.z/targetdistance)}
			end
			local entity = get_nearest_enemy(self,pos,50)
--			for _,entity in ipairs(minetest.get_objects_inside_radius(pos,25)) do
--				if entity:is_player() then
					if entity then
					animation = 2
					target = entity:getpos()
					target.y = target.y + 20
					self.targetvektor = vector.multiply(vector.normalize({x=target.x-pos.x,y=target.y-pos.y,z=target.z-pos.z}),def.speed)
					end
--					targetdistance = math.sqrt((targetvektor.x*targetvektor.x)+(targetvektor.y*targetvektor.y)+(targetvektor.z*targetvektor.z))
--					targetvektor = {x=(targetvektor.x/targetdistance)*def.speed,y=(targetvektor.y/targetdistance)*def.speed,z=(targetvektor.z/targetdistance)*def.speed}
--				end
--			end
			if self.timer > 1 then
					--	db({"TEST"},"Debug")
--				for _,obj in ipairs(minetest.get_objects_inside_radius(pos,def.size*2)) do
--					if obj:is_player() then
						local obj = get_nearest_enemy(self,pos,50,true)
						if obj then
									local oposss = obj:getpos()
						if vector.distance(pos,oposss) <=15 and minetest.line_of_sight(pos,oposss,2) then
						obj:punch(self.object, 1.0, {full_punch_interval=1.0,damage_groups = {fleshy=def.damage}})
						if math.random(1,60) == 1 then
							obj:set_hp(0)
						end
						end
					--	db({"TEST"},"Debug")
						spawn_fire(self,pos,oposss)
						self.timer = 0
						end
--					end
--				end
			end
			pos.y = pos.y - 1
			local n = minetest.get_node(pos).name
			if self.targetvektor and self.targetvektor.y < 0 and (n == "default:water_source" or n == "default:lava_source" or n == "default:mud" or n == "default:lava_source") then
				self.targetvektor.y = 0
			end
			pos.y = pos.y + 1
			if self.targetvektor then
				self.object:setvelocity(self.targetvektor)
				self.object:setyaw(math.atan2(self.targetvektor.z,self.targetvektor.x)-(math.pi/2))
			end
			animate(self, animation)
		end
	})
	register_spawn("dragons:" .. name, {"default:angmarsnow","default:mordordust_mapgen"},def.chanche)
--	register_spawn("dragons:" .. name, {"default:mordordust_mapgen"},def.chanche)
end
function register_jellyfish(def)
	register_jellyfish_advanced(def.name, {
		size = def.size,
		speed = def.speed,
		max_hp = def.max_hp,
		damage = def.damage,
		--drops = {{name = "dragons:jelly",chanche = 1,min = 1,max = 3}},
		chanche = def.chanche
	})
end
register_jellyfish({
	name = "bat",
	size =10,
	max_hp = 15000,
	damage = 80,
	chanche = 36000,
	speed = 10
})
--[[register_jellyfish({
	name = "b",
	size = 0.3,
	max_hp = 15,
	damage = 4,
	chanche = 40000
})
register_jellyfish({
	name = "c",
	size = 0.5,
	max_hp = 25,
	damage = 2,
	chanche = 20000
})
register_jellyfish({
	name = "d",
	size = 0.25,
	max_hp = 10,
	damage = 1,
	chanche = 20000
})
register_jellyfish({
	name = "e",
	size = 0.2,
	max_hp = 10,
	damage = 10,
	chanche = 80000,
	speed = 1.5
})
register_jellyfish({
	name = "f",
	size = 0.1,
	max_hp = 5,
	damage = 8,
	chanche = 40000,
	speed = 1
})
register_jellyfish({
	name = "g",
	size = 0.75,
	max_hp = 20,
	damage = 2,
	chanche = 20000,
	speed = 2.5
})
register_jellyfish({
	name = "h",
	size = 0.75,
	max_hp = 20,
	damage = 5,
	chanche = 80000,
	speed = 3
})]]
