-- Minetest mod: jellyfish
-- (c) Kai Gerd Müller
-- See README.txt for licensing and other information.
function register_spawn(name, nodes,chanche)
	minetest.register_abm({
		label = "spawn",
		catch_up = true,
		nodenames = nodes,
		interval = 10,
		chance = chanche,
		action = function(pos, node, _, active_object_count_wider)
			if active_object_count_wider < 3 then
				minetest.add_entity(pos, name)
			end
		end
	})
end
function register_jellyfish_advanced(name, def)
	local defbox = def.size/2
	local side2 = name .. "3.png"
	local side = name .. "2.png"
	local front = name .. "1.png"
	minetest.register_entity("fish:" .. name,{
		initial_properties = {
			name = "fish:" .. name,
			hp_max = def.max_hp,
			visual_size = {x = def.size*3, y = def.size*3, z = def.size*3},
			visual = "mesh",
			mesh = "fish.obj",
			textures = {"fishtex.png"},
			collisionbox = {-defbox, -defbox, -defbox, defbox, defbox, defbox},
			physical = true
		},
		-- ON ACTIVATE --
		on_punch = function(self)
			local pos = self.object:getpos()
			if self.object:get_hp() > 0 then return end
			local pos = self.object:getpos()
			pos.y = pos.y + 0.5
			self.object:remove()
			minetest.add_item(pos, ItemStack("farming:meat"))
		end,
		on_activate = function(self)
			self.hudwel = true
			self.orc = true
			self.dunlending = true
			targetvektor = {x=0, y = 0 , z = 0 }
			self.object:setacceleration({x = 0, y = 0, z = 0})
		--self.object:set_animation({x = 0,y = 250},250, 0)
			self.object:setvelocity({x = math.random(-1,1), y = math.random(-1,1), z = math.random(-1,1)})
			self.timer = 0
		end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = function(self, dtime)
			self.timer = self.timer+dtime
			if self.timer >= 120 then
				self.object:remove()
			end
			pos = self.object:getpos()
			if not(self.object:get_hp() > 0) then
				pos.y = pos.y + 0.5
				self.object:remove()
				obj = minetest.add_item(pos, ItemStack("fish:jelly " .. math.random(1, 3)))
				if obj then
				obj:setvelocity({x=math.random(-1,1), y=5, z=math.random(-1,1)})
				end
			end
			if math.random(1,50) == 1 then
				targetvektor = {x=math.random(-10,10),y=math.random(-10,10),z=math.random(-10,10)}
				targetdistance = math.sqrt((targetvektor.x*targetvektor.x)+(targetvektor.y*targetvektor.y)+(targetvektor.z*targetvektor.z))
				targetvektor = {x=(targetvektor.x/targetdistance)*def.speed,y=(targetvektor.y/targetdistance)*def.speed,z=(targetvektor.z/targetdistance)}
			end
			for _,entity in ipairs(minetest.get_objects_inside_radius(pos,25)) do
				if entity:is_player() then
					target = entity:getpos()
					targetvektor = {x=pos.x-target.x,y=pos.y-target.y,z=pos.z-target.z}
					targetdistance = math.sqrt((targetvektor.x*targetvektor.x)+(targetvektor.y*targetvektor.y)+(targetvektor.z*targetvektor.z))
					targetvektor = {x=(targetvektor.x/targetdistance)*def.speed,y=(targetvektor.y/targetdistance)*def.speed,z=(targetvektor.z/targetdistance)*def.speed}
					if minetest.get_node({x=pos.x,y=pos.y+1,z=pos.z}).name ~= "default:water_source" then
						targetvektor.y = -1
					end
				end
			end
			if minetest.get_node(pos).name ~= "default:water_source" then
				self.object:remove()
				minetest.add_item(pos, ItemStack("farming:meat"))
			end
			if targetvektor then
				self.object:setvelocity(targetvektor)
				self.object:set_properties({automatic_rotate = 0})
				self.object:setyaw(math.atan2(targetvektor.z,targetvektor.x)+(math.pi+(math.sin(self.timer*10)/3)))
			end
		end
	})
	register_spawn("fish:" .. name, "default:water_source",def.chanche)
end
function register_jellyfish(def)
	register_jellyfish_advanced(def.name, {
		size = def.size,
		speed = 2 or def.speed,
		max_hp = def.max_hp,
		damage = def.damage,
		drops = {{name = "farming:meat",chanche = 1,min = 1,max = 1}},
		chanche = def.chanche
	})
end

register_jellyfish({
	name = "fish",
	size = 0.75,
	max_hp = 6,
	damage = 5,
	chanche = 20000,
	speed = 3
})
